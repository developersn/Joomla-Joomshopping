<script type="text/javascript">
function check_pm_sn(){
    $_('payment_form').submit();
}
</script>