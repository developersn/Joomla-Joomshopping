<?php
defined('_JEXEC') or die('Restricted access');

jimport('sncore.include');

class pm_snjoomshopping extends PaymentRoot
{
    function __construct()
    {
        SNGlobal::loadLanguage('plg_system_sn_joomshopping',JPATH_ADMINISTRATOR);
    }

    function showPaymentForm($params, $pmconfigs)
	{
		include(dirname(__FILE__)."/paymentform.php");
	}

	/* function call in admin [paykarbandi] */
	function showAdminFormParams($params)
	{
        $array_params = array('sn_pin','sn_currency','sn_send_payer_info','transaction_end_status','transaction_pending_status','transaction_failed_status');
        foreach ($array_params as $key)
        {
            if(!isset($params[$key]))
            {
                $params[$key] = '';
            }
        }
        $orders = JSFactory::getModel('orders', 'JshoppingModel');
        include(dirname(__FILE__)."/adminparamsform.php");
	}
	
	/* Redirect To Bank */
	function showEndForm($pmconfigs, $order)
	{
        $app	= JFactory::getApplication();

        $email = !empty($order->email) ? $order->email : '';
        $amount =!empty($order->order_total) ? $order->order_total : 0;
        $orderId = !empty($order->order_id) ? $order->order_id : 0;

        $uri = JURI::getInstance();
        $liveUrlHost = $uri->toString(array("scheme",'host', 'port'));
        $pmMethod = $this->getPmMethod();
        $backUrl = $liveUrlHost.SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=return&js_paymentclass=".$pmMethod->payment_class).'&orderId='. $orderId;
        $cancelUrl = $liveUrlHost.SEFLink("index.php?option=com_jshopping&controller=checkout&task=step2&act=notify&js_paymentclass=".$pmMethod->payment_class."&no_lang=1");

        $pin = !empty($pmconfigs['sn_pin']) ? $pmconfigs['sn_pin'] : '';
        $currency = !empty($pmconfigs['sn_currency']) ? $pmconfigs['sn_currency'] : '';
        $sendPayerInfo = !empty($pmconfigs['sn_send_payer_info']) ? $pmconfigs['sn_send_payer_info'] : '';

        if($amount > 0)
        {
            $amount = SNApi::modifyPrice($amount,$currency);

            $data = array(
                'pin'=> $pin,
                'price'=> $amount,
                'callback'=> $backUrl,
                'order_id'=> $orderId,
                'email'=> $email,
                'description'=> '',
                'mobile'=> '',
            );

            list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'joomshopping');

            if($status == true)
            {
                $data['bank_callback_details'] = $resultData['bank_callback_details'];
                $data['au'] = $resultData['au'];

                SNApi::clearData();
                SNApi::setData($data);

                $html = '<div class="sn-joomshopping-go-to-bank">'.JText::_('SN_CONNECTING_TO_PORTAL').'</div>';
                $html .= SNGlobal::postData($resultData['form_details']['action'],$resultData['form_details']['fields'],100);
                echo $html;
                return;
            }
        }

        $app->redirect($cancelUrl, '<h5>'.$msg.'</h5>','Error');
	}
	
	/* After Return From Bank */
	function checkTransaction($pmconfigs, $order, $act)
	{
        $app	= JFactory::getApplication();
        $uri = JURI::getInstance();
        $pmMethod = $this->getPmMethod();
        $liveUrlHost = $uri->toString(array("scheme",'host', 'port'));
        $cancelUrl = $liveUrlHost.SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=cancel&js_paymentclass=".$pmMethod->payment_class).'&orderId='. $order->order_id;

	    $orderId = SNGlobal::getVar('orderId',0,'int');
        $au = SNGlobal::getVar('au','','none','request');

        $sessionData = SNApi::getData();
        if(!empty($orderId) && !empty($au) && !empty($sessionData) && $orderId = $sessionData['order_id'])
        {
            $bankData = array();
            foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
            {
                $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
            }

            $data = array (
                'pin' => $sessionData['pin'],
                'price' => $sessionData['price'],
                'order_id' => $sessionData['order_id'],
                'au' => $au,
                'bank_return' => $bankData,
            );

            list($status,$msg,$resultData) = SNApi::verify($data,'joomshopping');
            
            if($status == true)
            {
                $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;

                $successMsg = JText::_('SN_PAID_TRANSACTION');
                $successMsg = str_replace('{REF}',$bankAu,$successMsg);

                saveToLog("payment.log", "Status Complete. Order ID ".$orderId.". message: ". $successMsg);
                $app->enqueueMessage($successMsg,'message');
                return array(7,$successMsg,$bankAu);
            }
        }

        $errorMsg = JText::_('SN_UNPAID_TRANSACTION');
        saveToLog("payment.log", "Status failed. Order ID ".$orderId.". message: ".$errorMsg );
        $app->redirect($cancelUrl, '<h5>'.$errorMsg.'</h5>' , $msgType='Error');
	}

	/* Use For Verify - You Can Change Payment Status */
	function getStatusFromResCode($rescode, $pmconfigs)
    {
        return $rescode;
    }

	/* Call This Function After Bank */
	function getUrlParams($pmconfigs)
	{
		$params = array();
		$params['order_id'] = SNGlobal::getVar('orderId',0,'int');
		$params['hash'] = "";
		$params['checkHash'] = 0;
		$params['checkReturnParams'] = 1;
		return $params;
	}
}

?>