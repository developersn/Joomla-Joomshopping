<?php
/**
 * @package     Joomla - > Site and Administrator payment info
 * @subpackage  com_Jshopping
 * @subpackage 	trangell_Zarinpal
 * @copyright   trangell team => https://trangell.com
 * @copyright   Copyright (C) 20016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die();

$lang = JFactory::getLanguage();
$lang->load('plg_system_sn_joomshopping',JPATH_ADMINISTRATOR);

?>
<div class="col100">
<fieldset class="adminform">
<table class="admintable" width = "100%" >
 <tr>
   <td  class="key">
     <?php echo JText::_('SN_FIELD_PIN');?>
   </td>
    <td style="text-align: right;">
     <input type = "text" class = "inputbox" name = "pm_params[sn_pin]" size="100" value = "<?php echo $params['sn_pin']?>" />
     <?php echo JHTML::tooltip(JText::_('SN_FIELD_PIN_DESC'));?>
   </td>
 </tr>
 <tr>
   <td  class="key">
     <?php echo JText::_('SN_FIELD_CURRENCY');?>
   </td>
    <td style="text-align: right;">
     <?php
         $fields = array(
             1 => JText::_('SN_FIELD_CURRENCY_RIAL'),
             0 => JText::_('SN_FIELD_CURRENCY_TOMAN'),
         );
        print JHTML::_('select.genericlist',$fields, 'pm_params[sn_currency]', 'class = "inputbox" size = "1"', 'sn_currency', 'name', $params['sn_currency'] );
        print JHTML::tooltip(JText::_('SN_FIELD_CURRENCY_DESC'));
     ?>
     
   </td>
 </tr>
 <tr>
    <td  class="key">
        <?php echo JText::_('SN_FIELD_SEND_PAYER_INFO');?>
    </td>
    <td style="text-align: right;">
        <?php
            $fields = array(
                1 => JText::_('SN_FIELD_ENABLE'),
                0 => JText::_('SN_FIELD_DISABLE'),
            );
            print JHTML::_('select.genericlist',$fields, 'pm_params[sn_send_payer_info]', 'class = "inputbox" size = "1"', 'sn_send_payer_info', 'name', $params['sn_send_payer_info'] );
            print JHTML::tooltip(JText::_('SN_FIELD_SEND_PAYER_INFO_DESC'));
        ?>

    </td>
 </tr>
 <tr>
   <td class="key">
     <?php echo _JSHOP_TRANSACTION_END;?>
   </td>
   <td style="text-align: right;">
     <?php              
     print JHTML::_('select.genericlist', $orders->getAllOrderStatus(), 'pm_params[transaction_end_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_end_status'] );
     ?>
   </td>
 </tr>
 <tr>
   <td class="key">
     <?php echo _JSHOP_TRANSACTION_PENDING;?>
   </td>
   <td style="text-align: right;">
     <?php 
     echo JHTML::_('select.genericlist',$orders->getAllOrderStatus(), 'pm_params[transaction_pending_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_pending_status']);
     ?>
   </td>
 </tr>
 <tr>
   <td class="key">
     <?php echo _JSHOP_TRANSACTION_FAILED;?>
   </td>
   <td style="text-align: right;">
     <?php 
     echo JHTML::_('select.genericlist',$orders->getAllOrderStatus(), 'pm_params[transaction_failed_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_failed_status']);
     ?>
   </td>
 </tr>
</table>
</fieldset>
</div>
<div class="clr"></div>
