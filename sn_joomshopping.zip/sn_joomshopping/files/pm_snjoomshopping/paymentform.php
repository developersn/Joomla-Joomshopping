<script type="text/javascript">
    function check_pm_snjoomshopping()
    {
        jQuery('#payment_form').submit();
    }
</script>