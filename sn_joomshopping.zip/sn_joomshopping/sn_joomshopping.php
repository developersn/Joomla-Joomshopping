<?php
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

class plgSystemSn_joomshopping extends JPlugin
{
	function __construct(&$subject,$config)
	{
		parent::__construct($subject,$config);
	}
}