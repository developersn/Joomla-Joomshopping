<?php
defined('_JEXEC') or die('Restricted access');

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

if(!defined('DS'))
{
    define('DS',DIRECTORY_SEPARATOR);
}

class plgSystemSn_joomshoppingInstallerScript
{
    function preflight($type,$parent)
    {
        if(!JFolder::exists(JPATH_ADMINISTRATOR .DS. 'components' .DS. 'com_jshopping'))
        {
            Jerror::raiseWarning(null,'لطفا ابتدا افزونه جوم شاپینگ را نصب نمایید.');
            return false;
        }
    }

    function postflight($type,$parent)
    {
        /* Enable Plugin */
        $database = JFactory::getDBO();
        $query = "UPDATE `#__extensions` SET `enabled` = 1 WHERE `element` = 'sn_joomshopping'";
        $database->setQuery($query);
        $database->query();

        /* Move Libraries Files */
        $from = JPATH_ROOT .DS. 'plugins' .DS. 'system' .DS. 'sn_joomshopping' .DS. 'libraries' .DS;
        $to = JPATH_ROOT .DS. 'libraries' .DS;
        JFolder::copy($from,$to,'',true);

        if(JFolder::exists($from))
        {
            JFolder::delete($from);
        }

        $root = JPATH_ROOT .DS. 'plugins' .DS. 'system' .DS. 'sn_joomshopping' .DS. 'files';
        $copy = JPATH_ROOT .DS. 'components' .DS. 'com_jshopping' .DS. 'payments';

        if(JFolder::exists($root))
        {
            JFolder::copy($root .DS, $copy .DS, '', true);
        }

        jimport('sncore.include');

        if(strtolower($type) == 'install')
        {
            $query = "INSERT INTO `#__jshopping_payment_method` (`payment_id`, `payment_code`, `payment_class`, `payment_publish`, `payment_ordering`, `payment_params`, `payment_type`, `price`, `price_type`, `tax_id`, `image`, `show_descr_in_email`, `name_en-GB`, `description_en-GB`, `name_de-DE`, `description_de-DE`, `name_fa-IR`, `description_fa-IR`) VALUES
				  (2020, '', 'pm_snjoomshopping', 1, 6, '', 2, '0.00', 1, 1, '', 0, 'Sn', '', '', '', 'Sn', '');";
            SNGlobal::insert($query);
        }
    }

    function uninstall($parent)
    {
        jimport('sncore.include');

        $folder = JPATH_ROOT .DS. 'components' .DS. 'com_jshopping' .DS. 'payments' .DS. 'pm_snjoomshopping';
        if(JFolder::exists($folder))
        {
            JFolder::delete($folder);
        }

        $query = "DELETE FROM `#__jshopping_payment_method` WHERE `payment_id`='2020'";
        SNGlobal::delete($query);
    }
}